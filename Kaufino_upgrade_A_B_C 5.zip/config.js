/* Verwende ausschließlich den öffentlichen Supabase Publishable Key. Niemals service_role-Schlüssel in eine Website schreiben. */
window.KAUFINO_CONFIG = {
  SUPABASE_URL: "https://jgjlrsnfzyxqorpyqxed.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "sb_publishable_44C6Dqc5QoREgzoRiP-7Og_2gRUfZKC"
};
