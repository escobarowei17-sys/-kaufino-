-- Kaufino: create a public bucket for listing photos. Run this in Supabase SQL Editor.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('listing-images', 'listing-images', true, 5242880, array['image/jpeg','image/png','image/webp','image/gif','image/heic','image/heif'])
on conflict (id) do update set public = true, file_size_limit = 5242880, allowed_mime_types = excluded.allowed_mime_types;

alter table storage.objects enable row level security;

drop policy if exists "Public can view Kaufino listing photos" on storage.objects;
create policy "Public can view Kaufino listing photos" on storage.objects
for select to public using (bucket_id = 'listing-images');

drop policy if exists "Users can upload their own Kaufino listing photos" on storage.objects;
create policy "Users can upload their own Kaufino listing photos" on storage.objects
for insert to authenticated with check (bucket_id = 'listing-images' and (storage.foldername(name))[1] = (select auth.uid())::text);

drop policy if exists "Users can delete their own Kaufino listing photos" on storage.objects;
create policy "Users can delete their own Kaufino listing photos" on storage.objects
for delete to authenticated using (bucket_id = 'listing-images' and (storage.foldername(name))[1] = (select auth.uid())::text);
