KAUFINO – PACHET ACTUALIZAT

Include:
- Fotografii multiple per anunț (până la 5), încărcare în Supabase Storage și galerie în pagina anunțului.
- Marketplace responsive, categorii, căutare, filtrare după oraș, conturi și publicarea anunțurilor.
- PWA instalabilă pe iPhone/Android prin browser (manifest + service worker).

IMPORTANT
1. Pachetul folosește proiectul Supabase configurat în config.js și cheia publică furnizată anterior. Verifică să fie Publishable Key din Supabase; nu pune niciodată cheia service_role în fișiere publice.
2. În Supabase SQL Editor rulează scriptul storage_photos.sql dacă bucket-ul/politicile foto nu sunt deja configurate.
3. Schema tabelului listings trebuie să aibă coloanele: seller_id, title, description, price, category, city, image_urls (array JSON/text[] compatibil cu baza ta), status și created_at. Dacă tabelul tău are altă structură, adaptăm migrarea înainte de a modifica datele.
4. Încarcă TOATE fișierele din acest folder în Netlify, împreună, nu doar index.html. Păstrează numele: index.html, app.js, config.js, style.css etc.
5. Acesta este un site web instalabil (PWA), nu încă o aplicație nativă publicată în App Store/Google Play. Pentru App Store va trebui ulterior să fie împachetată ca aplicație și trimisă spre verificare Apple.
